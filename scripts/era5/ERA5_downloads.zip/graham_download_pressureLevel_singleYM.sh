#!/bin/bash
#SBATCH --job-name=era5pres
#SBATCH --time=0-3:0:00
#SBATCH --mem=1G
#SBATCH --account=rpp-kshook

module load python/3.8

year=$1
month=$2
coordinates=90/-180/-90/180
forcing_path=/project/rpp-kshook/gut428/summaWorkflow_data/domain_BowAtBanff/forcing/1_ERA5_raw_data/
jobnum=1

echo "download pressureLevel $year - $month"
echo "job number is $jobnum"

# Run the ERA5 downloads with the parallel command, and move them to background
python download_ERA5_pressureLevel_singleYM.py $year $coordinates $forcing_path $month