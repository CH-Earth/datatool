#!/bin/bash
#SBATCH --job-name=era5surf
#SBATCH --time=0-24:0:00
#SBATCH --mem=1G
#SBATCH --account=rpp-kshook

module load python/3.8

year=$1
month_start=$2
month_end=$3
coordinates=90/-180/-90/180
forcing_path=/project/rpp-kshook/CompHydCore/ClimateForcingData/ERA5/ERA5_for_SUMMA/1_ERA5_raw_data/
jobnum=$((month_end-month_start+1))

echo "download surfaceLevel $month_start - $month_end in $year"
echo "job number is $jobnum"

# --- Parallel runs
# Build the target variable (we need this because we can't use brace expansion based on 'arrayYears'
months=""; 
for (( m=$month_start; m<=$month_end; m++ )); do
 months="$months $m";
done

# Run the ERA5 downloads with the parallel command, and move them to background
parallel --jobs=$jobnum python download_ERA5_surfaceLevel_month.py ::: $months ::: $year ::: $coordinates ::: $forcing_path

