#!/bin/bash
#SBATCH --job-name=era5pres
#SBATCH --time=0-24:0:00
#SBATCH --mem=1G
#SBATCH --account=rpp-kshook

module load python/3.8

year_start=$1
year_end=$2
coordinates=90/-180/-90/180
forcing_path=/project/rpp-kshook/gut428/summaWorkflow_data/domain_BowAtBanff/forcing/1_ERA5_raw_data/
jobnum=$((year_end-year_start+1))

echo "download pressureLevel $year_start - $year_end"
echo "job number is $jobnum"

# --- Parallel runs
# Build the target variable (we need this because we can't use brace expansion based on 'arrayYears'
years=""; 
for (( year=$year_start; year<=$year_end; year++ )); do
 years="$years $year";
done

# Run the ERA5 downloads with the parallel command, and move them to background
parallel --jobs=$jobnum python download_ERA5_pressureLevel_annual.py ::: $years ::: $coordinates ::: $forcing_path