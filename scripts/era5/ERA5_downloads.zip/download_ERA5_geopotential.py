# Reference: https://github.com/CH-Earth/summaWorkflow_public/blob/master/3a_forcing/1b_download_geopotential/download_ERA5_geopotential.py

import cdsapi    # copernicus connection


file = '/Users/localuser/Research/ERA5_geopotential_global.nc'

# connect to Copernicus (requires .cdsapirc file in $HOME)
c = cdsapi.Client()

# specify and retrieve data
c.retrieve('reanalysis-era5-complete', {  # do not change this!
    'stream': 'oper',
    'levtype': 'sf',
    'param': '26/228007/27/28/29/30/43/74/129/160/161/162/163/172',
    'date': '2000-01-01', # does not matter
    'time': '00',  # /to/23/by/1',
    'grid': '0.25/0.25',  # Latitude/longitude grid: east-west (longitude) and north-south resolution (latitude).
    'format': 'netcdf',
}, file)
